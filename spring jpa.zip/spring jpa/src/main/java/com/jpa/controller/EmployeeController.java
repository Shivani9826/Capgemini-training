package com.jpa.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.entities.Employee;
import com.jpa.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/")
	public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
		if(employee.getManager() !=null && employee.getManager().getId()==null) {
			employee.setManager(null);
		}
		
		else if(employee.getManager()!=null){
			Employee manager=employeeService.getEmployee(employee.getManager().getId());
			employee.setManager(manager);
		}
		
		Employee savedEmployee = employeeService.createEmployee(employee);
		return ResponseEntity.ok(savedEmployee);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
		Employee updatedEmployee = employeeService.getEmployee(id);      //updateEmployee(id, employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployee(@PathVariable Long id) {
		Employee employee = employeeService.getEmployee(id);
		return ResponseEntity.ok(employee);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
		employeeService.deleteEmployee(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/name-starts-with-s")
	public ResponseEntity<List<Employee>> getEmployeesWithNameStartingWithS() {
		String s="S";
		List<Employee> employees = employeeService.getEmployeesWhoseNameStartsWith(s); // getEmployeesWithNameStartingWithS();
		return ResponseEntity.ok(employees);
	}

//@GetMapping("/with-permanent-address")
//public ResponseEntity<List<Employee>> getEmployeesWithPermanentAddress() {
//	List<Employee> employees = employeeService.getEmployeesWithPermanentAddress();
//		return ResponseEntity.ok(employees);
//	}

//	@GetMapping("/managers")
//	public ResponseEntity<Map<Employee, List<Employee>>> getManagersAndTheirReportees() {
//		Map<Employee, List<Employee>> managersAndReportees = employeeService.getManagersAndTheirReportees();
//		return ResponseEntity.ok(managersAndReportees);
//	}

//	@GetMapping("/department-counts")
//	public ResponseEntity<Map<String, Long>> getDepartmentCounts() {
//		Map<String, Long> departmentCounts = employeeService.getDepartmentCounts();
//		return ResponseEntity.ok(departmentCounts);
//	}

//	@GetMapping("/location-departments")
//	public ResponseEntity<Map<String, List<String>>> getLocationDepartments() {
//		Map<String, List<String>> locationDepartments = employeeService.getLocationDepartments();
//		return ResponseEntity.ok(locationDepartments);
//	}

//	@GetMapping("/")
//	public ResponseEntity<List<Employee>> getAllEmployees(@RequestParam(defaultValue = "ASC") String sortDirection,
//			@RequestParam(defaultValue = "0") int page) {
//		List<Employee> employees = employeeService.getAllEmployees(sortDirection, page);
//		return ResponseEntity.ok(employees);
//	}
}
