package com.jpa.entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="locations")
public class Location {
    @Id
    private Long id;
    private String name;
    
    @OneToMany(mappedBy = "location")
    @JsonBackReference
    private List<Department> departments = new ArrayList<>();
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Department> getDepartments() {
		return departments;
	}
	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}
	public Location(Long id, String name, List<Department> departments) {
		super();
		this.id = id;
		this.name = name;
		this.departments = departments;
	}
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}

