package com.jpa.entities;

import java.util.ArrayList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="employees")
public class Employee {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    
    @ManyToOne()
    @JoinColumn(name = "department_id",referencedColumnName = "departmentId")
    private Department department;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "manager_id")
    private Employee manager;
    
    @OneToMany(mappedBy = "manager")
    @JsonBackReference
    private List<Employee> repoty=new ArrayList<>();
    
    public List<Employee> getRepoty() {
		return repoty;
	}
	public void setRepoty(List<Employee> repoty) {
		this.repoty = repoty;
	}
	@OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="employee_id",referencedColumnName = "id")
    @JsonManagedReference
    private List<Address> addresses = new ArrayList<>();

    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee getManager() {
		return manager;
	}
	public void setManager(Employee manager) {
		this.manager = manager;
	}
	public List<Address>getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	public Employee(Long id, String name, Department department, Employee manager, List<Address> addresses) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
		this.manager = manager;
		this.addresses = addresses;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}

