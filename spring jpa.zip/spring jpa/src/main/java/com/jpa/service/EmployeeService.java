package com.jpa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jpa.entities.Employee;
import com.jpa.repository.AddressRepository;
import com.jpa.repository.EmployeeRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EmployeeService {
	private final EmployeeRepository employeeRepository;
	private final AddressRepository addressRepository;

	public EmployeeService(EmployeeRepository employeeRepository, AddressRepository addressRepository) {
		this.employeeRepository = employeeRepository;
		this.addressRepository = addressRepository;
	}

	public Employee createEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	public Employee updateEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	public Employee getEmployee(Long id) {
		return employeeRepository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
	}

	public void deleteEmployee(Long id) {
		employeeRepository.deleteById(id);
	}

	public List<Employee> getEmployeesWhoseNameStartsWith(String prefix) {
		return employeeRepository.findByNameStartingWith(prefix);
	}

}
