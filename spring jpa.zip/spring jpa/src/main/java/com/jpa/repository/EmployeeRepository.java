package com.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.jpa.entities.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByNameStartingWith(String prefix);
    @Query("SELECT e FROM Employee e JOIN e.addresses a WHERE a.addressType = 'permanent'")
    List<Employee> findEmployeesWithPermanentAddress();
    List<Employee> findByManager(Employee manager);
    @Query("SELECT d.name, COUNT(e) FROM Department d JOIN d.employees e GROUP BY d")
    List<Object[]> findEmployeeCountByDepartment();
    @Query("SELECT l.name, d.name FROM Location l JOIN l.departments d")
    List<Object[]> findDepartmentByLocation();
}

